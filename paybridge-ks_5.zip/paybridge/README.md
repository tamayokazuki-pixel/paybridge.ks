# PayBridge.ks — GitHub + Render Deployment Guide

## 🚀 Deploy in 4 Steps

---

### STEP 1 — Free Database: MongoDB Atlas (~5 min)

1. Go to **https://cloud.mongodb.com** → create free account
2. Click **"Build a Database"** → choose **M0 Free** → pick any region → Create
3. **Security Quickstart:**
   - Username: e.g. `paybridgeuser`
   - Password: e.g. `MyPassword123` (save this!)
   - Click **"Create User"**
4. **Network Access** → Add IP Address → click **"Allow Access from Anywhere"** (0.0.0.0/0) → Confirm
5. Click **"Connect"** → **"Drivers"** → copy the URI, which looks like:
   ```
   mongodb+srv://paybridgeuser:MyPassword123@cluster0.xxxxx.mongodb.net/?retryWrites=true&w=majority
   ```
   Add `/paybridge` before the `?` so it becomes:
   ```
   mongodb+srv://paybridgeuser:MyPassword123@cluster0.xxxxx.mongodb.net/paybridge?retryWrites=true&w=majority
   ```

---

### STEP 2 — Gmail App Password (~2 min)

1. Go to **https://myaccount.google.com/security**
2. Enable **2-Step Verification** (required)
3. Go to **https://myaccount.google.com/apppasswords**
4. App name: `PayBridge` → click **Create**
5. Copy the **16-character password** shown (e.g. `abcd efgh ijkl mnop`) — remove spaces when using it

---

### STEP 3 — Push to GitHub (~3 min)

1. Go to **https://github.com** → sign in → click **"New repository"**
2. Name it `paybridge-ks` → set to **Private** → click **"Create repository"**
3. Unzip the downloaded `paybridge-ks.zip`
4. Open a terminal inside the `paybridge` folder and run:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/paybridge-ks.git
   git push -u origin main
   ```
   *(Replace YOUR_USERNAME with your actual GitHub username)*

---

### STEP 4 — Deploy on Render (~5 min)

1. Go to **https://render.com** → sign up free (use "Sign in with GitHub")
2. Click **"New +"** → **"Web Service"**
3. Click **"Connect a repository"** → select your `paybridge-ks` repo
4. Fill in the settings:
   - **Name:** `paybridge-ks`
   - **Region:** any (closest to you)
   - **Branch:** `main`
   - **Runtime:** `Node`
   - **Build Command:** `npm install && npm run build`
   - **Start Command:** `npm start`
   - **Plan:** Free
5. Scroll down to **"Environment Variables"** → click **"Add Environment Variable"** and add ALL 6:

   | Key | Value |
   |-----|-------|
   | `MONGODB_URI` | Your full Atlas URI from Step 1 |
   | `JWT_SECRET` | Any random string e.g. `pb_jwt_secret_2025_xyz` |
   | `ADMIN_EMAIL` | `admin@paybridge.ks` |
   | `ADMIN_PASS` | Your chosen admin password |
   | `EMAIL_USER` | Your Gmail address |
   | `EMAIL_PASS` | 16-char App Password from Step 2 (no spaces) |

6. Click **"Create Web Service"**
7. Render builds and deploys — takes ~3 minutes
8. Your live URL: **https://paybridge-ks.onrender.com** ✅

---

## 🔑 Admin Login
- Go to: `https://your-render-url.onrender.com/login`
- Email: value of `ADMIN_EMAIL`
- Password: value of `ADMIN_PASS`
- You'll be redirected to `/admin`

---

## 🔄 How to Update Your Site Later
Any time you push to GitHub, Render auto-redeploys:
```bash
git add .
git commit -m "Your update message"
git push
```

---

## ⚠️ Render Free Tier Note
On the free plan, your service **sleeps after 15 minutes of inactivity**.
The first visit after sleep takes ~30 seconds to wake up. This is normal.
Upgrade to a paid plan ($7/mo) to keep it always-on.

---

## 💻 Run Locally
```bash
npm install
cp .env.example .env.local
# Edit .env.local with your real values
npm run dev
# Visit http://localhost:3000
```
