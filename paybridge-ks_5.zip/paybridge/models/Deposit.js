import mongoose from 'mongoose';

const DepositSchema = new mongoose.Schema({
  depId:    { type: String, unique: true },
  userId:   { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  userName: { type: String },
  email:    { type: String },
  amount:   { type: Number, required: true },
  address:  { type: String, required: true },
  status:   { type: String, enum: ['pending', 'approved', 'rejected'], default: 'pending' },
}, { timestamps: true });

export default mongoose.models.Deposit || mongoose.model('Deposit', DepositSchema);
