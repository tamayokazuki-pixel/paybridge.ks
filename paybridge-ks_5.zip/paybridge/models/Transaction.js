import mongoose from 'mongoose';

const TransactionSchema = new mongoose.Schema({
  txId:      { type: String, unique: true },
  type:      { type: String, enum: ['transfer', 'deposit'], required: true },
  fromId:    { type: String },
  fromName:  { type: String },
  toId:      { type: String, required: true },
  toName:    { type: String, required: true },
  amount:    { type: Number, required: true },
  note:      { type: String, default: '' },
}, { timestamps: true });

export default mongoose.models.Transaction || mongoose.model('Transaction', TransactionSchema);
