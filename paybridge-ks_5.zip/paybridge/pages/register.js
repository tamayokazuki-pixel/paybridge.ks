import { useState } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import { useRouter } from 'next/router';
import s from '../styles/Auth.module.css';

export default function Register() {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({ firstName:'', lastName:'', email:'', phone:'', password:'', confirm:'' });
  const [code, setCode] = useState('');
  const [err, setErr] = useState('');
  const [loading, setLoading] = useState(false);

  function set(k, v) { setForm(f => ({...f, [k]:v})); setErr(''); }

  async function handleSubmit() {
    if (!form.firstName||!form.lastName||!form.email||!form.phone||!form.password) return setErr('All fields required.');
    if (form.password.length < 6) return setErr('Password must be 6+ characters.');
    if (form.password !== form.confirm) return setErr('Passwords do not match.');
    setLoading(true);
    try {
      const r = await fetch('/api/auth/register', {
        method: 'POST', headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ firstName:form.firstName, lastName:form.lastName, email:form.email, phone:form.phone, password:form.password }),
      });
      const d = await r.json();
      if (!r.ok) { setErr(d.error); setLoading(false); return; }
      setStep(2);
    } catch { setErr('Network error. Try again.'); }
    setLoading(false);
  }

  async function handleVerify() {
    if (!code || code.length !== 6) return setErr('Enter the 6-digit code.');
    setLoading(true);
    try {
      const r = await fetch('/api/auth/verify', {
        method: 'POST', headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ email: form.email, code }),
      });
      const d = await r.json();
      if (!r.ok) { setErr(d.error); setLoading(false); return; }
      router.push('/login?verified=1');
    } catch { setErr('Network error. Try again.'); }
    setLoading(false);
  }

  return (
    <>
      <Head><title>Register — PayBridge.ks</title></Head>
      <div className={s.page}>
        <div className={s.card}>
          <Link href="/" className={s.brand}>
            <div className={s.brandIcon}>P</div>
            <span>PayBridge<span className={s.accent}>.ks</span></span>
          </Link>
          {step === 1 ? (
            <>
              <h2 className={s.title}>Create Account</h2>
              <p className={s.sub}>Join PayBridge.ks today</p>
              <div className={s.row2}>
                <input className={s.inp} placeholder="First Name" value={form.firstName} onChange={e=>set('firstName',e.target.value)} />
                <input className={s.inp} placeholder="Last Name" value={form.lastName} onChange={e=>set('lastName',e.target.value)} />
              </div>
              <input className={s.inp} type="email" placeholder="Email Address" value={form.email} onChange={e=>set('email',e.target.value)} />
              <input className={s.inp} type="tel" placeholder="Phone Number" value={form.phone} onChange={e=>set('phone',e.target.value)} />
              <input className={s.inp} type="password" placeholder="Password" value={form.password} onChange={e=>set('password',e.target.value)} />
              <input className={s.inp} type="password" placeholder="Confirm Password" value={form.confirm} onChange={e=>set('confirm',e.target.value)} />
              {err && <div className={s.err}>{err}</div>}
              <button className={s.btnPrimary} onClick={handleSubmit} disabled={loading}>{loading ? 'Sending code…' : 'Continue'}</button>
              <p className={s.footer2}>Already have an account? <Link href="/login" className={s.link}>Sign In</Link></p>
            </>
          ) : (
            <>
              <h2 className={s.title}>Verify Your Email</h2>
              <p className={s.sub}>We sent a 6-digit code to <b>{form.email}</b>. Check your inbox.</p>
              <input className={`${s.inp} ${s.codeInp}`} placeholder="000000" maxLength={6} value={code} onChange={e=>setCode(e.target.value)} />
              {err && <div className={s.err}>{err}</div>}
              <button className={s.btnPrimary} onClick={handleVerify} disabled={loading}>{loading ? 'Verifying…' : 'Verify & Create Account'}</button>
              <p className={s.footer2}><span className={s.link} onClick={()=>setStep(1)}>← Back</span></p>
            </>
          )}
        </div>
      </div>
    </>
  );
}
