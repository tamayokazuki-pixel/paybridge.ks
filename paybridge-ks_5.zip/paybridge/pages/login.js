import { useState } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import { useRouter } from 'next/router';
import s from '../styles/Auth.module.css';

export default function Login() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [pass, setPass] = useState('');
  const [err, setErr] = useState('');
  const [loading, setLoading] = useState(false);
  const verified = router.query.verified === '1';

  async function handleLogin() {
    if (!email || !pass) return setErr('Email and password required.');
    setLoading(true);
    try {
      const r = await fetch('/api/auth/login', {
        method: 'POST', headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ email, password: pass }),
      });
      const d = await r.json();
      if (!r.ok) { setErr(d.error); setLoading(false); return; }
      localStorage.setItem('pb_token', d.token);
      localStorage.setItem('pb_role', d.role);
      if (d.role === 'admin') router.push('/admin');
      else router.push('/dashboard');
    } catch { setErr('Network error. Try again.'); }
    setLoading(false);
  }

  return (
    <>
      <Head><title>Sign In — PayBridge.ks</title></Head>
      <div className={s.page}>
        <div className={s.card}>
          <Link href="/" className={s.brand}>
            <div className={s.brandIcon}>P</div>
            <span>PayBridge<span className={s.accent}>.ks</span></span>
          </Link>
          <h2 className={s.title}>Welcome Back</h2>
          <p className={s.sub}>Sign in to your account</p>
          {verified && <div className={s.success}>Account created! You can now sign in.</div>}
          <input className={s.inp} type="email" placeholder="Email Address" value={email} onChange={e=>{setEmail(e.target.value);setErr('');}} onKeyDown={e=>e.key==='Enter'&&handleLogin()} />
          <input className={s.inp} type="password" placeholder="Password" value={pass} onChange={e=>{setPass(e.target.value);setErr('');}} onKeyDown={e=>e.key==='Enter'&&handleLogin()} />
          {err && <div className={s.err}>{err}</div>}
          <button className={s.btnPrimary} onClick={handleLogin} disabled={loading}>{loading ? 'Signing in…' : 'Sign In'}</button>
          <p className={s.footer2}>No account? <Link href="/register" className={s.link}>Create one</Link></p>
        </div>
      </div>
    </>
  );
}
