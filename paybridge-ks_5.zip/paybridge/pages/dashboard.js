import { useState, useEffect, useCallback } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import s from '../styles/Dashboard.module.css';

function fmt(n) { return '$' + Number(n).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2}); }
function ago(ts) {
  const d = Date.now() - new Date(ts).getTime();
  if (d < 60000) return 'just now';
  if (d < 3600000) return Math.floor(d/60000)+'m ago';
  if (d < 86400000) return Math.floor(d/3600000)+'h ago';
  return Math.floor(d/86400000)+'d ago';
}

export default function Dashboard() {
  const router = useRouter();
  const [data, setData] = useState(null);
  const [tab, setTab] = useState('overview');
  const [modal, setModal] = useState(null);
  const [depAmt, setDepAmt] = useState('');
  const [depAddr, setDepAddr] = useState('');
  const [sendEmail, setSendEmail] = useState('');
  const [sendAmt, setSendAmt] = useState('');
  const [sendNote, setSendNote] = useState('');
  const [toast, setToast] = useState(null);
  const [loading, setLoading] = useState(false);

  function showToast(msg, type='ok') { setToast({msg,type}); setTimeout(()=>setToast(null),5000); }

  const load = useCallback(async () => {
    const token = localStorage.getItem('pb_token');
    if (!token) { router.push('/login'); return; }
    const r = await fetch('/api/user/me', { headers:{ Authorization:`Bearer ${token}` } });
    if (r.status === 401) { router.push('/login'); return; }
    setData(await r.json());
  }, [router]);

  useEffect(() => { load(); }, [load]);

  function logout() { localStorage.removeItem('pb_token'); localStorage.removeItem('pb_role'); router.push('/'); }

  async function requestDeposit() {
    if (!depAmt || isNaN(depAmt) || Number(depAmt)<=0) return showToast('Enter a valid amount.','err');
    setLoading(true);
    const token = localStorage.getItem('pb_token');
    const r = await fetch('/api/user/deposit', {
      method:'POST', headers:{'Content-Type':'application/json', Authorization:`Bearer ${token}`},
      body: JSON.stringify({ amount: depAmt }),
    });
    const d = await r.json();
    setLoading(false);
    if (!r.ok) return showToast(d.error,'err');
    setDepAddr(d.address);
    load();
    showToast('Deposit request submitted! Address sent to your email.','ok');
  }

  async function sendMoney() {
    if (!sendEmail) return showToast('Enter recipient email.','err');
    if (!sendAmt || isNaN(sendAmt) || Number(sendAmt)<=0) return showToast('Enter valid amount.','err');
    setLoading(true);
    const token = localStorage.getItem('pb_token');
    const r = await fetch('/api/user/send', {
      method:'POST', headers:{'Content-Type':'application/json', Authorization:`Bearer ${token}`},
      body: JSON.stringify({ recipientEmail: sendEmail, amount: sendAmt, note: sendNote }),
    });
    const d = await r.json();
    setLoading(false);
    if (!r.ok) return showToast(d.error,'err');
    setModal(null); setSendEmail(''); setSendAmt(''); setSendNote('');
    load();
    showToast('Transfer successful!','ok');
  }

  if (!data) return <div style={{minHeight:'100vh',background:'#060e1a',display:'flex',alignItems:'center',justifyContent:'center',color:'#4fc3f7',fontSize:16}}>Loading…</div>;

  const { user, transactions, deposits } = data;
  const myTx = transactions || [];
  const myDep = deposits || [];
  const pendingDep = myDep.filter(d=>d.status==='pending');

  return (
    <>
      <Head><title>Dashboard — PayBridge.ks</title></Head>
      <div className={s.page}>
        {/* Topbar */}
        <div className={s.topbar}>
          <div className={s.logo}><div className={s.logoIcon}>P</div>PayBridge<span className={s.accent}>.ks</span></div>
          <div className={s.topRight}>
            <span className={s.userName}>{user.firstName} {user.lastName}</span>
            <button className={s.logoutBtn} onClick={logout}>Logout</button>
          </div>
        </div>

        <div className={s.main}>
          {toast && <div className={toast.type==='ok'?s.toastOk:s.toastErr}>{toast.msg}</div>}

          {/* Balance card */}
          <div className={s.balCard}>
            <div className={s.balLabel}>Total Balance</div>
            <div className={s.balValue}>{fmt(user.balance)}</div>
            <div className={s.balId}>Account: PB-{user._id?.slice(-8).toUpperCase()}</div>
            <div className={s.balBtns}>
              <button className={s.btnPrimary} onClick={()=>{setModal('deposit');setDepAddr('');setDepAmt('');}}>+ Add Money</button>
              <button className={s.btnOutline} onClick={()=>setModal('send')}>↗ Send Money</button>
            </div>
          </div>

          {/* Tabs */}
          <div className={s.tabs}>
            {['overview','transactions','deposits'].map(t=>(
              <button key={t} onClick={()=>setTab(t)} className={tab===t?s.tabActive:s.tab}>{t.charAt(0).toUpperCase()+t.slice(1)}</button>
            ))}
          </div>

          {tab==='overview' && (
            <div className={s.statsGrid}>
              {[
                {label:'Transactions',value:myTx.length,icon:'📊'},
                {label:'Pending Deposits',value:pendingDep.length,icon:'⏳'},
                {label:'Received',value:fmt(myTx.filter(t=>t.toId===user._id).reduce((s,t)=>s+t.amount,0)),icon:'📥'},
                {label:'Sent',value:fmt(myTx.filter(t=>t.fromId===user._id).reduce((s,t)=>s+t.amount,0)),icon:'📤'},
              ].map(c=>(
                <div key={c.label} className={s.statCard}>
                  <div className={s.statIcon}>{c.icon}</div>
                  <div className={s.statValue}>{c.value}</div>
                  <div className={s.statLabel}>{c.label}</div>
                </div>
              ))}
            </div>
          )}

          {tab==='transactions' && (
            <div className={s.list}>
              <div className={s.listHeader}>Transaction History</div>
              {myTx.length===0 ? <div className={s.empty}>No transactions yet</div> : myTx.map(tx=>{
                const inc = tx.toId===user._id;
                return (
                  <div key={tx._id} className={s.txRow}>
                    <div>
                      <div className={s.txTitle}>{inc?`From: ${tx.fromName}`:`To: ${tx.toName}`}</div>
                      <div className={s.txSub}>{tx.txId} · {ago(tx.createdAt)}</div>
                      {tx.note && <div className={s.txNote}>"{tx.note}"</div>}
                    </div>
                    <div className={inc?s.txAmtIn:s.txAmtOut}>{inc?'+':'-'}{fmt(tx.amount)}</div>
                  </div>
                );
              })}
            </div>
          )}

          {tab==='deposits' && (
            <div className={s.list}>
              <div className={s.listHeader}>My Deposit Requests</div>
              {myDep.length===0 ? <div className={s.empty}>No deposit requests</div> : myDep.sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt)).map(d=>(
                <div key={d._id} className={s.depRow}>
                  <div>
                    <div className={s.txTitle}>{fmt(d.amount)}</div>
                    <div className={s.addrText}>{d.address}</div>
                    <div className={s.txSub}>{ago(d.createdAt)}</div>
                  </div>
                  <span className={s['status_'+d.status]}>{d.status.toUpperCase()}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Deposit Modal */}
        {modal==='deposit' && (
          <div className={s.overlay}>
            <div className={s.modal}>
              <div className={s.modalHead}><h3>Add Money</h3><button onClick={()=>setModal(null)} className={s.closeBtn}>×</button></div>
              {!depAddr ? (
                <>
                  <p className={s.modalSub}>Enter the amount you'd like to deposit. A unique address will be generated for your transaction.</p>
                  <input className={s.inp} type="number" placeholder="Amount (e.g. 500)" value={depAmt} onChange={e=>setDepAmt(e.target.value)} />
                  <button className={s.btnPrimary} onClick={requestDeposit} disabled={loading}>{loading?'Generating…':'Request Deposit Address'}</button>
                </>
              ) : (
                <>
                  <p className={s.modalSub}>Send exactly <b style={{color:'#4fc3f7'}}>{fmt(depAmt)}</b> to this address:</p>
                  <div className={s.addrBox}>{depAddr}</div>
                  <div className={s.warning}>⚠ Your deposit is pending admin approval. You'll be notified once credited.</div>
                  <button className={s.btnOutline} onClick={()=>setModal(null)}>Close</button>
                </>
              )}
            </div>
          </div>
        )}

        {/* Send Modal */}
        {modal==='send' && (
          <div className={s.overlay}>
            <div className={s.modal}>
              <div className={s.modalHead}><h3>Send Money</h3><button onClick={()=>setModal(null)} className={s.closeBtn}>×</button></div>
              <input className={s.inp} type="email" placeholder="Recipient Email" value={sendEmail} onChange={e=>setSendEmail(e.target.value)} />
              <input className={s.inp} type="number" placeholder="Amount" value={sendAmt} onChange={e=>setSendAmt(e.target.value)} />
              <input className={s.inp} placeholder="Note (optional)" value={sendNote} onChange={e=>setSendNote(e.target.value)} />
              <div className={s.balHint}>Your balance: <b style={{color:'#4fc3f7'}}>{fmt(user.balance)}</b></div>
              <button className={s.btnPrimary} onClick={sendMoney} disabled={loading}>{loading?'Sending…':'Send'}</button>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
