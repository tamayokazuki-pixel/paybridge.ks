import { Html, Head, Main, NextScript } from 'next/document';
export default function Document() {
  return (
    <Html lang="en">
      <Head>
        <meta charSet="UTF-8" />
        <link rel="icon" href="/favicon.ico" />
        <meta name="description" content="PayBridge.ks — Secure Digital Banking" />
      </Head>
      <body>
        <Main />
        <NextScript />
      </body>
    </Html>
  );
}
