import Head from 'next/head';
import Link from 'next/link';
import styles from '../styles/Landing.module.css';

export default function Home() {
  const stats = [
    { value: '2019', label: 'Founded', sub: 'Years of trusted service' },
    { value: '500K+', label: 'Users', sub: 'Registered accounts' },
    { value: '30+', label: 'Countries', sub: 'Global reach' },
    { value: '99.9%', label: 'Uptime', sub: 'System reliability' },
  ];
  const features = [
    { icon: '🔒', title: 'Bank-Level Security', desc: '256-bit encryption protects every transaction and your personal data.' },
    { icon: '⚡', title: 'Instant Transfers', desc: 'Send and receive money instantly within the PayBridge network.' },
    { icon: '🌍', title: 'Global Reach', desc: 'Transact across borders with competitive rates.' },
    { icon: '📱', title: 'Anywhere Access', desc: 'Full account access from any device or browser.' },
  ];

  return (
    <>
      <Head><title>PayBridge.ks — Secure Digital Banking</title></Head>
      <div className={styles.page}>
        {/* Nav */}
        <nav className={styles.nav}>
          <div className={styles.logo}>
            <div className={styles.logoIcon}>P</div>
            <span>PayBridge<span className={styles.accent}>.ks</span></span>
          </div>
          <div className={styles.navLinks}>
            <Link href="/login" className={styles.navBtn}>Sign In</Link>
            <Link href="/register" className={styles.navBtnPrimary}>Create Account</Link>
          </div>
        </nav>

        {/* Hero */}
        <section className={styles.hero}>
          <div className={styles.heroBadge}>Secure · Fast · Trusted</div>
          <h1 className={styles.heroTitle}>Your Complete<br /><span className={styles.gradient}>Financial Hub</span></h1>
          <p className={styles.heroSub}>PayBridge.ks delivers secure digital banking — deposit, transfer, and manage money with confidence.</p>
          <div className={styles.heroBtns}>
            <Link href="/register" className={styles.btnPrimary}>Open Free Account</Link>
            <Link href="/login" className={styles.btnOutline}>Sign In →</Link>
          </div>
        </section>

        {/* Stats */}
        <section className={styles.statsSection}>
          <div className={styles.statsGrid}>
            {stats.map(s => (
              <div key={s.label} className={styles.statCard}>
                <div className={styles.statValue}>{s.value}</div>
                <div className={styles.statLabel}>{s.label}</div>
                <div className={styles.statSub}>{s.sub}</div>
              </div>
            ))}
          </div>
        </section>

        {/* Features */}
        <section className={styles.featuresSection}>
          <h2 className={styles.sectionTitle}>Why PayBridge?</h2>
          <p className={styles.sectionSub}>Everything you need, nothing you don't</p>
          <div className={styles.featuresGrid}>
            {features.map(f => (
              <div key={f.title} className={styles.featureCard}>
                <div className={styles.featureIcon}>{f.icon}</div>
                <div className={styles.featureTitle}>{f.title}</div>
                <div className={styles.featureDesc}>{f.desc}</div>
              </div>
            ))}
          </div>
        </section>

        {/* CTA */}
        <section className={styles.cta}>
          <h2>Ready to get started?</h2>
          <p>Join thousands already banking smarter with PayBridge.ks</p>
          <Link href="/register" className={styles.btnPrimary}>Create Free Account</Link>
        </section>

        <footer className={styles.footer}>
          © 2025 PayBridge.ks — All rights reserved &nbsp;·&nbsp; support@paybridge.ks
        </footer>
      </div>
    </>
  );
}
