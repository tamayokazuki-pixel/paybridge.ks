import { connectDB } from '../../../lib/db';
import User from '../../../models/User';
import Deposit from '../../../models/Deposit';
import { requireAuth } from '../../../lib/auth';
import { sendMail, depositAddressEmail } from '../../../lib/email';

function genId() { return 'PB' + Date.now().toString(36).toUpperCase(); }
function genAddress() {
  const c = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  return '0x' + Array.from({ length: 40 }, () => c[Math.floor(Math.random() * c.length)]).join('');
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const auth = requireAuth(req);
    if (!auth || auth.role !== 'user') return res.status(401).json({ error: 'Unauthorized' });

    const { amount } = req.body;
    if (!amount || isNaN(amount) || Number(amount) <= 0)
      return res.status(400).json({ error: 'Invalid amount.' });

    await connectDB();
    const user = await User.findById(auth.id);
    if (!user) return res.status(404).json({ error: 'User not found' });

    const address = genAddress();
    const dep = await Deposit.create({
      depId: genId(),
      userId: user._id,
      userName: user.firstName + ' ' + user.lastName,
      email: user.email,
      amount: Number(amount),
      address,
    });

    try {
      await sendMail({
        to: user.email,
        subject: 'PayBridge.ks — Your Deposit Address',
        html: depositAddressEmail(user.firstName, amount, address),
      });
    } catch (e) { console.error('Email error:', e.message); }

    res.status(200).json({ address, depId: dep.depId });
  } catch (err) {
    console.error('Deposit error:', err.message);
    res.status(500).json({ error: 'Server error: ' + err.message });
  }
}
