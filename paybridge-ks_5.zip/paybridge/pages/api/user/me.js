import { connectDB } from '../../../lib/db';
import User from '../../../models/User';
import Transaction from '../../../models/Transaction';
import Deposit from '../../../models/Deposit';
import { requireAuth } from '../../../lib/auth';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(200).end();

  try {
    const auth = requireAuth(req);
    if (!auth || auth.role !== 'user') return res.status(401).json({ error: 'Unauthorized' });

    await connectDB();
    const user = await User.findById(auth.id).select('-password -verifyCode -verifyExp');
    if (!user) return res.status(404).json({ error: 'User not found' });

    const [transactions, deposits] = await Promise.all([
      Transaction.find({ $or: [{ fromId: auth.id }, { toId: auth.id }] }).sort({ createdAt: -1 }).limit(50),
      Deposit.find({ userId: auth.id }).sort({ createdAt: -1 }),
    ]);

    res.status(200).json({ user, transactions, deposits });
  } catch (err) {
    console.error('Me error:', err.message);
    res.status(500).json({ error: 'Server error: ' + err.message });
  }
}
