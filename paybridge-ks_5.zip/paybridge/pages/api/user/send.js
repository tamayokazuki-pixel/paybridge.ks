import { connectDB } from '../../../lib/db';
import User from '../../../models/User';
import Transaction from '../../../models/Transaction';
import { requireAuth } from '../../../lib/auth';
import { sendMail, moneyReceivedEmail } from '../../../lib/email';

function genId() { return 'PB' + Date.now().toString(36).toUpperCase(); }

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const auth = requireAuth(req);
    if (!auth || auth.role !== 'user') return res.status(401).json({ error: 'Unauthorized' });

    const { recipientEmail, amount, note } = req.body;
    if (!recipientEmail || !amount || isNaN(amount) || Number(amount) <= 0)
      return res.status(400).json({ error: 'Invalid request.' });

    await connectDB();
    const sender = await User.findById(auth.id);
    if (!sender) return res.status(404).json({ error: 'Sender not found' });
    if (sender.email === recipientEmail.toLowerCase()) return res.status(400).json({ error: 'Cannot send to yourself.' });

    const recipient = await User.findOne({ email: recipientEmail.toLowerCase() });
    if (!recipient) return res.status(404).json({ error: 'Recipient not found.' });

    const amt = Number(amount);
    if (sender.balance < amt) return res.status(400).json({ error: 'Insufficient balance.' });

    sender.balance -= amt;
    recipient.balance += amt;
    await sender.save();
    await recipient.save();

    const tx = await Transaction.create({
      txId: genId(),
      type: 'transfer',
      fromId: sender._id.toString(),
      fromName: sender.firstName + ' ' + sender.lastName,
      toId: recipient._id.toString(),
      toName: recipient.firstName + ' ' + recipient.lastName,
      amount: amt,
      note: note || '',
    });

    try {
      await sendMail({
        to: recipient.email,
        subject: 'PayBridge.ks — You received money!',
        html: moneyReceivedEmail(recipient.firstName, sender.firstName + ' ' + sender.lastName, amt, note, recipient.balance),
      });
    } catch (e) { console.error('Email error:', e.message); }

    res.status(200).json({ message: 'Transfer successful.', newBalance: sender.balance, tx });
  } catch (err) {
    console.error('Send error:', err.message);
    res.status(500).json({ error: 'Server error: ' + err.message });
  }
}
