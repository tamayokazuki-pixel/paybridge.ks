import { connectDB } from '../../../lib/db';
import User from '../../../models/User';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    await connectDB();
    const { email, code } = req.body;
    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) return res.status(400).json({ error: 'User not found.' });
    if (user.isVerified) return res.status(400).json({ error: 'Already verified.' });
    if (user.verifyCode !== code) return res.status(400).json({ error: 'Invalid verification code.' });
    if (new Date() > user.verifyExp) return res.status(400).json({ error: 'Code expired. Please register again.' });

    user.isVerified = true;
    user.verifyCode = null;
    user.verifyExp = null;
    await user.save();

    res.status(200).json({ message: 'Email verified successfully.' });
  } catch (err) {
    console.error('Verify error:', err.message);
    res.status(500).json({ error: 'Server error: ' + err.message });
  }
}
