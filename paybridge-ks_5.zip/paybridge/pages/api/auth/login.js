import { connectDB } from '../../../lib/db';
import User from '../../../models/User';
import bcrypt from 'bcryptjs';
import { signToken } from '../../../lib/auth';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password required.' });

    const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'admin@paybridge.ks';
    const ADMIN_PASS  = process.env.ADMIN_PASS  || 'Admin@2025';

    if (email === ADMIN_EMAIL && password === ADMIN_PASS) {
      const token = signToken({ role: 'admin', email });
      return res.status(200).json({ token, role: 'admin' });
    }

    await connectDB();
    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) return res.status(400).json({ error: 'Invalid credentials.' });
    if (!user.isVerified) return res.status(400).json({ error: 'Please verify your email first.' });

    const valid = await bcrypt.compare(password, user.password);
    if (!valid) return res.status(400).json({ error: 'Invalid credentials.' });

    const token = signToken({ id: user._id.toString(), role: 'user', email: user.email });
    res.status(200).json({
      token,
      role: 'user',
      user: {
        id: user._id.toString(),
        _id: user._id.toString(),
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        phone: user.phone,
        balance: user.balance,
      },
    });
  } catch (err) {
    console.error('Login error:', err.message);
    res.status(500).json({ error: 'Server error: ' + err.message });
  }
}
