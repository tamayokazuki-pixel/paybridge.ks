import { connectDB } from '../../../lib/db';
import User from '../../../models/User';
import bcrypt from 'bcryptjs';
import { sendMail, verificationEmail } from '../../../lib/email';

export default async function handler(req, res) {
  // Allow CORS for Netlify
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(200).end();

  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    await connectDB();
  } catch (e) {
    console.error('DB connection failed:', e.message);
    return res.status(500).json({ error: 'Database connection failed. Please check your MONGODB_URI environment variable in Netlify settings.' });
  }

  try {
    const { firstName, lastName, email, phone, password } = req.body;

    if (!firstName || !lastName || !email || !phone || !password)
      return res.status(400).json({ error: 'All fields are required.' });
    if (password.length < 6)
      return res.status(400).json({ error: 'Password must be at least 6 characters.' });

    const existing = await User.findOne({ email: email.toLowerCase() });
    if (existing) return res.status(400).json({ error: 'Email already registered.' });

    const hashed = await bcrypt.hash(password, 10);
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    const exp = new Date(Date.now() + 10 * 60 * 1000);

    await User.create({
      firstName,
      lastName,
      email: email.toLowerCase(),
      phone,
      password: hashed,
      verifyCode: code,
      verifyExp: exp,
    });

    try {
      await sendMail({
        to: email,
        subject: 'PayBridge.ks — Verify Your Email',
        html: verificationEmail(firstName, code),
      });
    } catch (emailErr) {
      console.error('Email sending failed:', emailErr.message);
      // Don't block registration if email fails — return code in dev mode
      if (process.env.NODE_ENV !== 'production') {
        return res.status(200).json({ message: 'Verification code sent.', devCode: code });
      }
    }

    res.status(200).json({ message: 'Verification code sent to your email.' });
  } catch (err) {
    console.error('Register error:', err.message);
    res.status(500).json({ error: 'Server error: ' + err.message });
  }
}
