import { connectDB } from '../../../lib/db';
import User from '../../../models/User';
import Deposit from '../../../models/Deposit';
import Transaction from '../../../models/Transaction';
import { requireAuth } from '../../../lib/auth';
import { sendMail, depositApprovedEmail } from '../../../lib/email';

function genId() { return 'PB' + Date.now().toString(36).toUpperCase(); }

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const auth = requireAuth(req);
    if (!auth || auth.role !== 'admin') return res.status(401).json({ error: 'Unauthorized' });

    const { depId, action } = req.body;
    if (!depId || !['approve', 'reject'].includes(action))
      return res.status(400).json({ error: 'Invalid request.' });

    await connectDB();
    const dep = await Deposit.findOne({ depId });
    if (!dep) return res.status(404).json({ error: 'Deposit not found.' });
    if (dep.status !== 'pending') return res.status(400).json({ error: 'Already processed.' });

    if (action === 'approve') {
      dep.status = 'approved';
      await dep.save();

      const user = await User.findById(dep.userId);
      if (user) {
        user.balance += dep.amount;
        await user.save();

        await Transaction.create({
          txId: genId(),
          type: 'deposit',
          fromId: 'SYSTEM',
          fromName: 'PayBridge Deposit',
          toId: user._id.toString(),
          toName: dep.userName,
          amount: dep.amount,
          note: 'Deposit approved by admin',
        });

        try {
          await sendMail({
            to: dep.email,
            subject: 'PayBridge.ks — Deposit Approved!',
            html: depositApprovedEmail(dep.userName.split(' ')[0], dep.amount, user.balance),
          });
        } catch (e) { console.error('Email error:', e.message); }
      }
    } else {
      dep.status = 'rejected';
      await dep.save();
    }

    res.status(200).json({ message: `Deposit ${action}d successfully.` });
  } catch (err) {
    console.error('Deposit action error:', err.message);
    res.status(500).json({ error: 'Server error: ' + err.message });
  }
}
