import { connectDB } from '../../../lib/db';
import User from '../../../models/User';
import Transaction from '../../../models/Transaction';
import Deposit from '../../../models/Deposit';
import { requireAuth } from '../../../lib/auth';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(200).end();

  try {
    const auth = requireAuth(req);
    if (!auth || auth.role !== 'admin') return res.status(401).json({ error: 'Unauthorized' });

    await connectDB();
    const [users, transactions, deposits] = await Promise.all([
      User.find().select('-password -verifyCode -verifyExp').sort({ createdAt: -1 }),
      Transaction.find().sort({ createdAt: -1 }).limit(100),
      Deposit.find().sort({ createdAt: -1 }),
    ]);

    res.status(200).json({ users, transactions, deposits });
  } catch (err) {
    console.error('Admin overview error:', err.message);
    res.status(500).json({ error: 'Server error: ' + err.message });
  }
}
