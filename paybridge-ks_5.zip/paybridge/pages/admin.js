import { useState, useEffect, useCallback } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import s from '../styles/Admin.module.css';

function fmt(n) { return '$'+Number(n).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2}); }
function ago(ts) {
  const d = Date.now()-new Date(ts).getTime();
  if (d<60000) return 'just now';
  if (d<3600000) return Math.floor(d/60000)+'m ago';
  if (d<86400000) return Math.floor(d/3600000)+'h ago';
  return Math.floor(d/86400000)+'d ago';
}

export default function Admin() {
  const router = useRouter();
  const [data, setData] = useState(null);
  const [tab, setTab] = useState('overview');
  const [search, setSearch] = useState('');
  const [toast, setToast] = useState(null);

  function showToast(msg,type='ok'){setToast({msg,type});setTimeout(()=>setToast(null),4000);}

  const load = useCallback(async () => {
    const token = localStorage.getItem('pb_token');
    const role = localStorage.getItem('pb_role');
    if (!token||role!=='admin') { router.push('/login'); return; }
    const r = await fetch('/api/admin/overview',{headers:{Authorization:`Bearer ${token}`}});
    if (r.status===401){router.push('/login');return;}
    setData(await r.json());
  },[router]);

  useEffect(()=>{load();},[load]);
  useEffect(()=>{const t=setInterval(load,5000);return()=>clearInterval(t);},[load]);

  function logout(){localStorage.removeItem('pb_token');localStorage.removeItem('pb_role');router.push('/');}

  async function depositAction(depId,action){
    const token=localStorage.getItem('pb_token');
    const r=await fetch('/api/admin/deposit-action',{
      method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},
      body:JSON.stringify({depId,action}),
    });
    const d=await r.json();
    if(!r.ok) return showToast(d.error,'err');
    showToast(`Deposit ${action}d successfully.`,'ok');
    load();
  }

  if(!data) return <div style={{minHeight:'100vh',background:'#060e1a',display:'flex',alignItems:'center',justifyContent:'center',color:'#ef5350',fontSize:16}}>Loading admin panel…</div>;

  const {users,transactions,deposits}=data;
  const pending=deposits.filter(d=>d.status==='pending');
  const filtered=users.filter(u=>(u.firstName+' '+u.lastName+u.email).toLowerCase().includes(search.toLowerCase()));
  const allTx=[...transactions].sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt));
  const allDep=[...deposits].sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt));

  return (
    <>
      <Head><title>Admin Panel — PayBridge.ks</title></Head>
      <div className={s.page}>
        <div className={s.topbar}>
          <div className={s.logo}><div className={s.logoIcon}>A</div>PayBridge<span className={s.accent}>.ks</span><span className={s.adminBadge}>Admin</span></div>
          <div className={s.topRight}>
            {pending.length>0&&<span className={s.pendingBadge}>{pending.length} pending</span>}
            <button className={s.logoutBtn} onClick={logout}>Logout</button>
          </div>
        </div>
        <div className={s.main}>
          {toast&&<div className={toast.type==='ok'?s.toastOk:s.toastErr}>{toast.msg}</div>}
          <div className={s.tabs}>
            {[
              {id:'overview',label:'Overview'},
              {id:'deposits',label:`Deposits${pending.length>0?` (${pending.length})`:''}`,},
              {id:'users',label:'Users'},
              {id:'transactions',label:'Transactions'},
            ].map(t=>(
              <button key={t.id} onClick={()=>setTab(t.id)} className={tab===t.id?s.tabActive:s.tab}>{t.label}</button>
            ))}
          </div>

          {tab==='overview'&&(
            <>
              <div className={s.statsGrid}>
                {[
                  {label:'Total Users',value:users.length,c:'#4fc3f7'},
                  {label:'Pending Approvals',value:pending.length,c:'#ffc107'},
                  {label:'All Deposits',value:deposits.length,c:'#26a69a'},
                  {label:'All Transactions',value:transactions.length,c:'#ef5350'},
                  {label:'Total Funds',value:fmt(users.reduce((sum,u)=>sum+u.balance,0)),c:'#7c4dff'},
                ].map(c=>(
                  <div key={c.label} className={s.statCard}>
                    <div style={{fontSize:22,fontWeight:900,color:c.c}}>{c.value}</div>
                    <div className={s.statLabel}>{c.label}</div>
                  </div>
                ))}
              </div>
              <div className={s.liveBox}>
                <div className={s.liveTitle}>🔴 Live Activity Feed <span className={s.liveDot} /></div>
                {allTx.slice(0,15).map(tx=>(
                  <div key={tx._id} className={s.liveRow}>
                    <div><span className={s.liveNames}>{tx.fromName} → {tx.toName}</span><span className={s.liveSub}> · {ago(tx.createdAt)} · {tx.type}</span></div>
                    <span style={{color:'#26a69a',fontWeight:700,fontSize:14}}>{fmt(tx.amount)}</span>
                  </div>
                ))}
                {allTx.length===0&&<div className={s.empty}>No transactions yet. Auto-refreshing every 5s.</div>}
              </div>
            </>
          )}

          {tab==='deposits'&&(
            <div>
              <div className={s.sectionTitle}>Deposit Requests ({deposits.length})</div>
              {allDep.map(d=>(
                <div key={d._id} className={s.depCard} style={{borderColor:d.status==='pending'?'#ffc107':d.status==='approved'?'#26a69a':'#ef5350'}}>
                  <div className={s.depLeft}>
                    <div className={s.depName}>{d.userName}</div>
                    <div className={s.depMeta}>{d.email} · {ago(d.createdAt)}</div>
                    <div className={s.depAddr}>{d.address}</div>
                    <div className={s.depAmt}>{fmt(d.amount)}</div>
                  </div>
                  <div className={s.depRight}>
                    <span className={s['status_'+d.status]}>{d.status.toUpperCase()}</span>
                    {d.status==='pending'&&(
                      <div className={s.depActions}>
                        <button className={s.approveBtn} onClick={()=>depositAction(d.depId,'approve')}>✓ Approve</button>
                        <button className={s.rejectBtn} onClick={()=>depositAction(d.depId,'reject')}>✗ Reject</button>
                      </div>
                    )}
                  </div>
                </div>
              ))}
              {deposits.length===0&&<div className={s.empty}>No deposit requests yet.</div>}
            </div>
          )}

          {tab==='users'&&(
            <div>
              <input className={s.searchInp} placeholder="Search by name or email…" value={search} onChange={e=>setSearch(e.target.value)} />
              <div className={s.sectionTitle}>Registered Users ({filtered.length})</div>
              {filtered.map(u=>(
                <div key={u._id} className={s.userCard}>
                  <div className={s.userLeft}>
                    <div className={s.avatar}>{u.firstName[0]}{u.lastName[0]}</div>
                    <div>
                      <div className={s.userName2}>{u.firstName} {u.lastName}</div>
                      <div className={s.userMeta}>{u.email} · {u.phone}</div>
                      <div className={s.userId}>ID: {u._id} · Joined {ago(u.createdAt)}</div>
                    </div>
                  </div>
                  <div className={s.userBal}>
                    <div style={{fontWeight:900,fontSize:18,color:'#26a69a'}}>{fmt(u.balance)}</div>
                    <div style={{color:'#3a5a75',fontSize:12}}>Balance</div>
                  </div>
                </div>
              ))}
              {filtered.length===0&&<div className={s.empty}>No users found.</div>}
            </div>
          )}

          {tab==='transactions'&&(
            <div>
              <div className={s.sectionTitle}>All Transactions ({allTx.length})</div>
              {allTx.map(tx=>(
                <div key={tx._id} className={s.txCard}>
                  <div>
                    <div className={s.txNames}>{tx.fromName} → {tx.toName}</div>
                    <div className={s.txMeta}>{tx.txId} · {ago(tx.createdAt)} · {tx.type}</div>
                    {tx.note&&<div className={s.txNote}>Note: {tx.note}</div>}
                  </div>
                  <span style={{fontWeight:800,fontSize:16,color:'#26a69a'}}>{fmt(tx.amount)}</span>
                </div>
              ))}
              {allTx.length===0&&<div className={s.empty}>No transactions yet.</div>}
            </div>
          )}
        </div>
      </div>
    </>
  );
}
